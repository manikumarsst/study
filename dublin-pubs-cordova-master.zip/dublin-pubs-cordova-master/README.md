dublin-pubs-cordova
===========

A cordova app built with google maps and angular JS to show the pubs that me and Kev have drank in
