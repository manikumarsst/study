# mappd
## A mobile application to share map locations across friends

This application features an offline map caching characteristic that saves into the app itself the maps previously navigated so they are available the next time you open the application saving data and allowing the app to be used in offline mode.
To use this app you need to setup the backend files that are available for download at https://github.com/lalcaraz/mappd/backend/
