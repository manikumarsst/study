ons.ready(function() {
	
		
});

	