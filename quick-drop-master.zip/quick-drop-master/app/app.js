var NG_MODULE = 'MyApp'
!function () {
	angular.module(NG_MODULE, ['onsen', 'ionic']);
}();