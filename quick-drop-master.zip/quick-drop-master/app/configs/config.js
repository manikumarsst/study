!function () {

	function config ($ionicPlatform) {
	}
	config.$inject = ['$ionicPlatform'];
	angular.module(NG_MODULE).run(config);
	
}();


