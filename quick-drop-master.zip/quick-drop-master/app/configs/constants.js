!function () {

	angular.module(NG_MODULE)
		.constant('VERSION', '0.0.1');

}();
