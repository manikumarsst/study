# gdg-sudeste-hackathon

Aplicativo de sugestão de pontos turísticos de Belo Horizonte.
O usuário irá visualizar o mapa com alguns pontos turísticos mais próximos dele. Ele também poderá filtrar os lugars por um raio de KM de sua preferência. 

Equipe:
Rodrigo Castro 
Breno Henrique
Arthur Alfredo
Diegton Rodrigues

