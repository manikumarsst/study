Corkboard is a hybrid app built with Ionic and Cordova, using the Camera/Geolocation Cordova APIs and the Angular Google Maps API. This app 
allows users to plot their pictures on a map by location. By clicking on a map marker, the user can view the pictures taken at that location. 
Currently, picture-taking is only supported for the android deployment. On the web app, a user can log in and view previous pictures. There is 
only one user currently, with the username "user", and the password "secret". 

Known Bugs:
1. Android: Markers are sometimes not clickable
2. Android: Picture upload gets interrupted