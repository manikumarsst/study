angular.module('app.controllers', [])

.controller('NoticiasController', function ($scope, Noticias) {    
    var myDataPromise = Noticias.all();    
    myDataPromise.then(function(data) {  // this is only run after $http completes
       $scope.noticias = data.data;        
        
        //corregir el formato de la fecha
        var noticias = $scope.noticias;
        
        for(var i = 0; i < noticias.length; i++) {
            noticias[i].Fecha = fixDate(noticias[i].Fecha);
        }
        ///
        
    $scope.showDetail = function(index) {
        var myDataPromise = Noticias.get($scope.noticias[index].Id);    
        myDataPromise.then(function(data) {  // this is only run after $http completes
            $scope.noticia = data.data;
            ons.slidingMenu.setSwipeable(false);
            
            //corregir el formato de la fecha
            $scope.noticia.Fecha = fixDate($scope.noticia.Fecha);
            ///
                        
            $scope.ons.navigator.pushPage('templates/noticia.html', {noticia : $scope.noticia});
        });
    }    
    });
})
.controller('NoticiaController', function ($scope, $sce, Noticias) {  
    $scope.noticia = ons.navigator.getCurrentPage().options.noticia;
    
    //(fix ng-bind-html) necesario con angularjs para mostrar html desde la base de datos
    $scope.contenido = $sce.trustAsHtml($scope.noticia.Contenido);
})

.controller('PonenciasController', function ($scope, Ponencias) {
    var myDataPromise = Ponencias.all();    
    myDataPromise.then(function(data) {  // this is only run after $http completes
       $scope.ponencias = data.data;
        
        //corregir el formato de la fecha
        var ponencias = $scope.ponencias;
        
        for(var i = 0; i < ponencias.length; i++) {
            var tiempo = dateDiff(ponencias[i].FechaInicio, ponencias[i].FechaFin);
            ponencias[i].FechaInicio = fixDate(ponencias[i].FechaInicio);
            ponencias[i].FechaFin = tiempo;
        }
        ///        
        
    
    $scope.showDetail = function(index) {
        var myDataPromise = Ponencias.get($scope.ponencias[index].Id);    
        myDataPromise.then(function(data) {  // this is only run after $http completes
            $scope.ponencia = data.data;
            ons.slidingMenu.setSwipeable(false);
         
            //corregir el formato de la fecha
            var tiempo = dateDiff($scope.ponencia.FechaInicio, $scope.ponencia.FechaFin);
            $scope.ponencia.FechaInicio = fixDate($scope.ponencia.FechaInicio);
            $scope.ponencia.FechaFin = tiempo;
            ///                                
            
            $scope.ons.navigator.pushPage('templates/ponencia.html', {ponencia : $scope.ponencia});
        });
    }    
    });
})
.controller('PonenciaController', function ($scope, $sce, Ponencias) {
    $scope.ponencia = ons.navigator.getCurrentPage().options.ponencia;
    $scope.contenido = $sce.trustAsHtml($scope.ponencia.Contenido);
})


.controller('PonentesController', function ($scope, Ponentes) {
    var myDataPromise = Ponentes.all();    
    myDataPromise.then(function(data) {  // this is only run after $http completes
       $scope.ponentes = data.data;    
    
    $scope.showDetail = function(index) {
        var myDataPromise = Ponentes.get($scope.ponentes[index].ponente.Id);    
        myDataPromise.then(function(data) {  // this is only run after $http completes
            $scope.ponente = data.data;
            ons.slidingMenu.setSwipeable(false);
            
            $scope.ons.navigator.pushPage('templates/ponente.html', {ponente : $scope.ponente});
        });
    }    
    });
})
.controller('PonenteController', function ($scope, $sce, Ponentes) {
    $scope.ponente = ons.navigator.getCurrentPage().options.ponente;
    $scope.contenido = $sce.trustAsHtml($scope.ponente.Contenido);
})

.controller('PatrocinadoresController', function ($scope, Patrocinadores) {
    var myDataPromise = Patrocinadores.all();    
    myDataPromise.then(function(data) {  // this is only run after $http completes
       $scope.patrocinadores = data.data;
    
    $scope.showDetail = function(index) {
        var myDataPromise = Patrocinadores.get($scope.patrocinadores[index].patrocinador.Id);    
        myDataPromise.then(function(data) {  // this is only run after $http completes
            $scope.patrocinador = data.data;
            ons.slidingMenu.setSwipeable(false);
            
            $scope.ons.navigator.pushPage('templates/patrocinador.html', {patrocinador : $scope.patrocinador});
        });
    }    
    });
})
.controller('PatrocinadorController', function ($scope, $sce, Patrocinadores) {
    $scope.patrocinador = ons.navigator.getCurrentPage().options.patrocinador;
    $scope.contenido = $sce.trustAsHtml($scope.patrocinador.Contenido);
})


.controller('MapaController', function ($scope, Mapa) {
    
    ons.slidingMenu.setSwipeable(false);
    
    var myDataPromise = Mapa.all();    
    myDataPromise.then(function(data) {  // this is only run after $http completes
       $scope.mapa = data.data[0].lugar;    //la app solo deberia tener un lugar
        

        //Map initialization  
        var latlng = new google.maps.LatLng($scope.mapa.Latitud, $scope.mapa.Longitud);
            var myOptions = {
                zoom: 16,
                center: latlng,
                mapTypeId: google.maps.MapTypeId.HYBRID
            };
          
        $scope.map = new google.maps.Map(document.getElementById("map"), myOptions); 
        
        var marker = new google.maps.Marker({
            position: latlng,
            map: $scope.map,
            title: $scope.mapa.Titulo
        });
        
        var infowindow = new google.maps.InfoWindow({
            content: "<p><b>"+$scope.mapa.Titulo+"</b></p><p>"+$scope.mapa.Descripcion+"</p><p>"+$scope.mapa.Contenido+"</p>"
        });
        
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open($scope.map, marker);
        });
        
        
        $scope.overlay = new google.maps.OverlayView();
        $scope.overlay.draw = function() {}; // empty function required
        $scope.overlay.setMap($scope.map);
    });
})