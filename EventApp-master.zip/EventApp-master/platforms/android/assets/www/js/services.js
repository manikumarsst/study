angular.module('app.services', [])

.factory('Noticias', ['$http', function ($http) {
    
    var all = function() {
        var url = "http://yii.javiergarciachavez.es/web/api/index/"+idApp+"/noticia";
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };
    var get = function(noticiaId) {
        var url = "http://yii.javiergarciachavez.es/web/api/view/noticia/"+noticiaId;
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };

    return { 
        all: all,
        get: get
    };
}])

.factory('Ponencias', ['$http', function ($http) {
    
    var all = function() {
        var url = "http://yii.javiergarciachavez.es/web/api/index/"+idApp+"/ponencia";
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };
    var get = function(ponenciaId) {
        var url = "http://yii.javiergarciachavez.es/web/api/view/ponencia/"+ponenciaId;
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };

    return { 
        all: all,
        get: get
    };
}])

.factory('Ponentes', ['$http', function ($http) {
    
    var all = function() {
        var url = "http://yii.javiergarciachavez.es/web/api/index/"+idApp+"/ponente";
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };
    var get = function(ponenteId) {
        var url = "http://yii.javiergarciachavez.es/web/api/view/ponente/"+ponenteId;
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };

    return { 
        all: all,
        get: get
    };
}])

.factory('Patrocinadores', ['$http', function ($http) {
    
    var all = function() {
        var url = "http://yii.javiergarciachavez.es/web/api/index/"+idApp+"/patrocinador";
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };
    var get = function(patrocinadorId) {
        var url = "http://yii.javiergarciachavez.es/web/api/view/patrocinador/"+patrocinadorId;
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };

    return { 
        all: all,
        get: get
    };
}])

.factory('Mapa', ['$http', function ($http) {
    
    var all = function() {
        var url = "http://yii.javiergarciachavez.es/web/api/index/"+idApp+"/lugar";
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };
    var get = function(lugarId) {
        var url = "http://yii.javiergarciachavez.es/web/api/view/lugar/"+lugarId;
        return $http({method: 'GET', url: url}).then(function(data) { return data.data; });
    };

    return { 
        all: all,
        get: get
    };
}])