angular.module('app', ['onsen', 'app.controllers', 'app.services'])

.controller('AppController', function($scope) {
    $scope.doSomething = function() {
        setTimeout(function() {
        alert('tapped');
        }, 100);
    };
});

//ocultar el splashscreen al iniciar la app
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    navigator.splashscreen.hide();
}

function fixDate(date) {    
    //arreglar la fecha
    var fecha = new Date(date);
    var dd = fecha.getDate();
    var mm = fecha.getMonth()+1; //Enero es 0!

    var yyyy = fecha.getFullYear();
    if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    
    //arreglar la hora
    var hour = fecha.getHours();
    if(hour<10) {
        hour = '0'+hour;
    }
    var min = fecha.getMinutes();
    if(min<10) {
        min = '0'+min;
    }

    //formar string
    var fecha = dd+'/'+mm+'/'+yyyy + ' ' + hour+':'+min; 

    return fecha;
}

function dateDiff(fecha1, fecha2) {
    var date1 = new Date(fecha1);
    var date2 = new Date(fecha2);
    var timeDiff = Math.abs(date2.getTime() - date1.getTime());
    
    var diff = timeDiff/3600/1000*60; //diferencia en minutos
    
    return diff + " minutos";
}