app.controller('BlogCtrl', function($scope, $state, $location, $ionicPopup, ionicMaterialInk) {
  
})