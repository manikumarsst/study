var tanApp = angular.module('tanApp');

// Stops Data: JSON Stops configuration
tanApp.factory('StopsData', function(){
    
    var data = { url: 'json/arrets.json'}; //https://open.tan.fr/ewp/arrets.json
    
    return data;
});

tanApp.factory('HorairesArretsData', function(){
    
    var data = { url: 'https://open.tan.fr/ewp/tempsattente.json/'};
    
    return data;
});
