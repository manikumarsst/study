/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicity call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        //var parentElement = document.getElementById(id);
        //var listeningElement = parentElement.querySelector('.listening');
        //var receivedElement = parentElement.querySelector('.received');

        //listeningElement.setAttribute('style', 'display:none;');
        //receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

(function() {
    var app = angular.module('tanApp', ['onsen.directives', 'ngTouch', 'ngSanitize', 'angular-carousel', 'google-maps'.ns(), 'ui.map', 'ui.event', 'nvd3']);
    
    app.config(['$httpProvider', function($httpProvider) {

        $httpProvider.defaults.headers.common['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.cache = false;
		$httpProvider.defaults.useXDomain = true;
		$httpProvider.defaults.withCredentials = true;
		delete $httpProvider.defaults.headers.common["X-Requested-With"];
		$httpProvider.defaults.headers.common["Accept"] = "application/json";
		$httpProvider.defaults.headers.common["Content-Type"] = "application/json";
		$httpProvider.defaults.headers.common["Accept-Language"] = "fr_FR";

    }]);
	
	app.controller('StopsController', function($scope, $http, StopsData) {
        
        $scope.stops = [];
		
        var getData = function ($done) {
            $http({method: 'GET', url: 'json/arrets.json'}).
            success(function(data, status, headers, config) {
                
                if ($done) { $done(); }
                
                $scope.stops = data.arrets;
                
            }).
            error(function(data, status, headers, config) {
                
                if ($done) { $done(); }

            });
        
        }
            
        // Initial Data Loading
        getData();

        $scope.load = function($done) {
            getData($done);
        };
        
        $scope.showDetail = function(index) {
			var selectedItem = $scope.stops[index];
			StopsData.selectedItem = selectedItem;
			$scope.appNavigator.pushPage('schedule.html', selectedItem);
        }
        
        // getStops() function()
        $scope.getStops = function() {
            // Filter Stops by $scope.search
            return $scope.stops.filter(function(item) {
                
                // Filter Stops by Title
                var itemDoesMatch = !$scope.search ||
                item.libelle.toLowerCase().indexOf($scope.search.toLowerCase()) > -1;
                
                // Filter Stops by Title or Body
                //var itemDoesMatch = !$scope.search ||
                //item.title.toLowerCase().indexOf($scope.search.toLowerCase()) > -1 || 
                //item.body.toLowerCase().indexOf($scope.search.toLowerCase()) > -1;
                
                return itemDoesMatch;
            });
        };

        // Search Detail function()
        $scope.showSearchDetail = function(index) {
			var items = $scope.getStops();
			var selectedItem = items[index];
			StopsData.selectedItem = selectedItem;
			$scope.appNavigator.pushPage('schedule.html', selectedItem);
        }
        
    });
    
    // Stop Controller
    app.controller('ScheduleController', function($scope, $http, StopsData) {
        $scope.item = StopsData.selectedItem;
		
		var getData = function ($done) {
            $http({method: 'GET', url: 'json/testta.json'}). // arrets.codeLieu
            success(function(data, status, headers, config) {
                
                if ($done) { $done(); }
                
                $scope.infos = data;
                
            }).
            error(function(data, status, headers, config) {
                
                if ($done) { $done(); }

            });
        
        }
		
		getData();

        $scope.load = function($done) {
            getData($done);
        };
		
		$scope.date = new Date();
		
    });
    
    // Filter
    app.filter('partition', function($cacheFactory) {
          var arrayCache = $cacheFactory('partition');
          var filter = function(arr, size) {
            if (!arr) { return; }
            var newArr = [];
            for (var i=0; i<arr.length; i+=size) {
                newArr.push(arr.slice(i, i+size));        
            }
            var cachedParts;
            var arrString = JSON.stringify(arr);
            cachedParts = arrayCache.get(arrString+size); 
            if (JSON.stringify(cachedParts) === JSON.stringify(newArr)) {
              return cachedParts;
            }
            arrayCache.put(arrString+size, newArr);
            return newArr;
          };
          return filter;
        });


})();
