# Resto App
Description :

The app is built with Ionic Framework. The app is for android and IOS. The app using google Map API .

Tools:

Ionic Framework, Google Map API, Jquery.

Cordova Plugins:
1. Camera
2. File
3. File Transfer
4. Console

